package com.gildedgames.launcher.ui.resources;

import java.awt.Color;

public class LauncherStyles {
	public static final Color LAUNCHER_BACKGROUND = new Color(0x212529);
}
