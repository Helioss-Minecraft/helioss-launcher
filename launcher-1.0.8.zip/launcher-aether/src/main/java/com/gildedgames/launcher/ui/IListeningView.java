package com.gildedgames.launcher.ui;

public interface IListeningView {
	void reload();
}
