package com.skcraft.launcher.model.modpack;

import lombok.Data;

@Data
public class LatestVersions {

    private String release;
    private String snapshot;

}