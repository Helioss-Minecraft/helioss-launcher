#!/bin/sh
./gradlew clean build
read -p "Press any key to continue..."